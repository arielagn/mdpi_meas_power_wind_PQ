from scipy import signal
import numpy as np
import matplotlib.pyplot as plt
import fliker
# Instancia del objeto fliker
f=fliker.fliker(2000,50,220)
"""
Generar señal de prueva 
"""
# Datos comunes a todas las funciones
fs    = 2000   #Freq sampling
U_nom = 220    #Nominal voltage
line_freq = 50 #Frecuencia de linea
du_u = 0.196   #input relative voltage fluctuation delta U/U [%]
ff   = 8.8     #frecuencia de flucuacion [Hz]
tl   = 120     #Longitud en tiempo [s]
square=True    #Modulada cuadrada
    
up = U_nom * np.sqrt(2)
t  = np.arange(0,tl,1/fs)

if (square):
    u = up * np.sin( 2* np.pi * line_freq *t) * (1+0.5* du_u  /100 * np.sign(np.sin(2*np.pi*ff*t)))
else:
    u = up * np.sin( 2* np.pi * line_freq *t) * (1+0.5* du_u  /100 * np.sin(2*np.pi*ff*t))
"""
plt.rcParams.update({'font.size': 22})
plt.figure()
plt.xlabel('tiempo (s)')
plt.ylabel('Amplitud (V)')
plt.ylim(310,312)
plt.title('Voltaje')
plt.plot(t[:2000],u[:2000]) # muestro solo el 1er segundo
plt.grid()
plt.show()
"""

"""
Para normalizar la señal de tension. Amplitud centrada en 1
"""
'Voltage adaptor low pass filter 27,3s'
num = [1]
den = [27.3,1]

#filtro pasa bajos Tc=27,3s.
vrms = f.rms(u)
'Voltage adaptor low pass filter 27,3s'
lti = signal.lti(num,den)
z1, p1 = signal.bilinear(lti.num,lti.den,fs)
zi1 = signal.lfilter_zi(z1, p1)
z,h = signal.lfilter(z1, p1, vrms,zi=zi1*vrms[0])
z=z*np.sqrt(2)
v=u/z
"""
plt.rcParams.update({'font.size': 22})
plt.figure(1)
plt.xlabel('tiempo (s)')
plt.ylabel('Amplitud (V)')
plt.title('Voltaje')
plt.ylim(0.98,+1.02)
plt.plot(t[:2000],v[:2000])
plt.grid()
plt.show()

plt.figure(2)
w, h = signal.freqs(num,den)
plt.semilogx(w, 20 * np.log10(abs(h)))
plt.title('Respuesta en frecuencia filtro pasa bajos')
plt.xlabel('Frecuencia (r/s)')
plt.ylabel('Amplitud (dB)')
plt.margins(0, 0.1)
plt.grid(which='both', axis='both')
plt.axvline(0.0366, color='green') # cutoff frequency
plt.show()
"""
v=v**2
'Weighting filter block3 1st order HP 6th order LP'
tc = 1/ (2 * np.pi * 0.05)
num=[tc,0]
den=[tc,1]
#lti2=signal.lti(num,den)
# Pasa bajo
wn =2*np.pi* 35 #frecuencia de corte para 50Hz
# -filtro Butterworth de 6to orden
b, a = signal.iirfilter(6,wn , rp=None, rs=None, btype='lowpass', analog=True, ftype='butter', output='ba')
#lti3=signal.lti(b,a)
# Combinando los filtros
lti4=signal.lti(np.polymul(b,num),np.polymul(a,den))
#Digitalizacion
z2,p2=signal.bilinear(lti4.num,lti4.den,fs)

# Aplico primer filtro pasa banda bloque 3
zi2 = signal.lfilter_zi(z2,p2)
z,h = signal.lfilter(z2,p2,v,zi=zi2*v[0])
"""
plt.rcParams.update({'font.size': 22})
plt.figure(1)
w, h = signal.freqs(lti4.num,lti4.den)
plt.semilogx(w, 20 * np.log10(abs(h)))
plt.title('Respuesta en frecuencia del Filtro')
plt.xlabel('Frecuencia (r/s)')
plt.ylabel('Amplitud (dB)')
plt.margins(0, 0.1)
plt.grid(which='both', axis='both')
plt.axvline(0.314, color='green') # cutoff frequency 0.05Hz
plt.axvline(220, color='green') # cutoff frequency 35Hz
plt.show()
"""
'Weighting filter block3'
k=1.74802 # valores para 50Hz
lamda=2*np.pi*4.05981
omega1=2*np.pi*9.15494
omega2=2*np.pi*2.27979
omega3=2*np.pi*1.22535
omega4=2*np.pi*21.9

num1=[k*omega1,0]
den1=[1,2*lamda,omega1**2]
num2=[1/omega2,1]
den2=[1/omega3,1]
den3=[1/omega4,1]
den4=np.polymul(den2,den3)
num5=np.polymul(num1,num2)
den5=np.polymul(den1,den4)
lti5=signal.lti(num5,den5)
#Digitalizacion
z3,p3=signal.bilinear(lti5.num,lti5.den,fs)
# Aplico segundo filtro bloque 3
zi3 = signal.lfilter_zi(z3,p3)
z,h = signal.lfilter(z3,p3,z,zi=zi3*z[0])
"""
plt.rcParams.update({'font.size': 22})
plt.figure(1)
w, h = signal.freqs(lti5.num,lti5.den)
plt.semilogx(w, 20 * np.log10(abs(h)))
plt.title('Respuesta en frecuencia del Filtro')
plt.xlabel('Frecuencia (r/s)')
plt.ylabel('Amplitud (dB)')
plt.margins(0, 0.1)
plt.grid(which='both', axis='both')
plt.show()
"""
'Pasa bajos de 1er orden 0.3s de constante de tiempoo'
# frecuencia de corte 0,53Hz w=3.33
num=[1]
den=[0.3,1]
lti=signal.lti(num,den)
z4,p4=signal.bilinear(lti.num,lti.den,fs)
# cuadrado y filtro bloque 4
z=z**2
# Segundo paso smoothing
zi4 = signal.lfilter_zi(z4,p4)
z,h = signal.lfilter(z4,p4,z,zi=zi4*z[0])
"""
plt.rcParams.update({'font.size': 22})
plt.figure(1)
w, h = signal.freqs(lti.num,lti.den)
plt.semilogx(w, 20 * np.log10(abs(h)))
plt.title('Respuesta en frecuencia del Filtro')
plt.xlabel('Frecuencia (r/s)')
plt.ylabel('Amplitud (dB)')
plt.margins(0, 0.1)
plt.grid(which='both', axis='both')
plt.axvline(3.33, color='green') # cutoff frequency 0.53Hz
plt.show()
"""
# Multiplicador
z = z*1.24e6


plt.rcParams.update({'font.size': 22})
plt.figure(1)
plt.xlabel('tiempo (s)')
plt.ylabel('Amplitud (V)')
plt.title('Voltaje')
plt.ylim(0.98,+1.02)
plt.plot(t[:2000],v[:2000])
plt.grid()
plt.show()

plt.figure(2)
plt.xlabel('tiempo (s)')
plt.ylabel('Amplitud Pinst')
plt.title('Pinst')
#plt.ylim(0.98,+1.02)
plt.plot(t[238000:],z[238000:])
plt.grid()
plt.show()


