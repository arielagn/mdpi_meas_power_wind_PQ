import matplotlib.pyplot as plt
import numpy as np
import fliker
# Instancia del objeto fliker
f=fliker.fliker(2000,50,220)
# Genera señal de prueba DU/U=0.250%, 8.8Hz 120sg pert senoidal
u,t = f.genSignal(0.250,8.8,120,False)
# Normalizo la señal
v = f.normSignal(u)
# Aplico filtros
z = f.filters(v)
# Obtiene maximo descartando 20sg iniciales
print(np.amax(z[80000:]))
# Grafico fig 10
"""
plt.rcParams.update({'font.size': 22})
plt.figure()
plt.xlabel('tiempo (s)')
plt.ylabel('Amplitud')
plt.ylim(0.9,1.02)
plt.title('Pinst')
plt.plot(t,z)


plt.grid()
plt.show()
"""
# Genera señal de prueba DU/U=0.407%, 1620CPM 120sg pert senoidal
u,t = f.genSignal(0.407,13.5,120,True)
v = f.normSignal(u)
z = f.filters(v)
ps,perc,pst = f.fliker(z[80000:],25) # de 40sg a 120sg intervalo 1min 20seg
print("Para 1620 CPM; 0.407 DU/U Pst:",pst," Error %: ",(pst-1)*100)
#Valores minimos y maximos por clase
print("Valores minimos de persepcion instantaneas de las clases")
print(ps[1])
print("Valores maximos de persepcion instantaneas de las clases")
print(ps[2])
# Grafico

plt.rcParams.update({'font.size': 22})
plt.figure(1)
plt.xlabel('Clases')
plt.ylabel('Ocurrencias')
plt.title('Función Densidad de Probabilidad')
plt.plot(ps[0])
# Grafico 2
plt.figure(2)
plt.xlabel('Clases')
plt.ylabel('Probabilidad acumulativa (%)')
plt.title('Función de Probabilidad Acumulada')
plt.plot(ps[3])
# Valores percentiles
print("Percentil 0.1%=",perc[1])
print("Percentil 0.7%=",perc[2])
print("Percentil 1%=",perc[3])
print("Percentil 1.5%=",perc[4])
print("Percentil 2.2%=",perc[5])
print("Percentil 3%=",perc[6])
print("Percentil 4%=",perc[7])
print("Percentil 6%=",perc[8])
print("Percentil 8%=",perc[9])
print("Percentil 10%=",perc[10])
print("Percentil 13%=",perc[11])
print("Percentil 17%=",perc[12])
print("Percentil 30%=",perc[13])
print("Percentil 50%=",perc[14])
print("Percentil 80%=",perc[15])
print("Promedio entre percentiles 0.7, 1 y 1.3=",perc[16])
print("Promedio entre percentiles 2.2, 3 y 4=",perc[17])
print("Promedio entre percentiles 6, 8, 10, 13 y 17=",perc[18])
print("Promedio entre percentiles 30, 50 y 80=",perc[19])

plt.grid()
plt.show()

