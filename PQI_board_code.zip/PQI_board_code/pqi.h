/*
 * pqi.h
 *
 *  Created on: May 18, 2023
 *      Author: ariel
 */

#ifndef PQI_H_
#define PQI_H_

#include "arm_math.h"
#define idle 0
#define iniciar_medicion 1
#define midiendo 2
#define medicion_terminada 3
#define iniciar_muestra_t 4
#define muestra_t 5
#define muestra_t_terminada 6
#define iniciar_cal 7
#define calibracion 8
#define cal_terminada 9

extern float32_t resultados[800];

uint16_t Pqi_getCounter();
void Pqi_setCounter(uint16_t count);
void Pqi_resetIndex();
void Adc_ConvHandler(uint16_t,uint16_t);
void Pqi_task(uint8_t);
uint8_t Pqi_getSts();
void Pqi_setSts(uint8_t sts);
float32_t Pqi_get_v_dc_offset();
void Pqi_set_v_dc_offset(float32_t val);
float32_t Pqi_get_v_scale();
void Pqi_set_v_scale(float32_t val);
float32_t Pqi_get_i_dc_offset();
void Pqi_set_i_dc_offset(float32_t val);
float32_t Pqi_get_i_scale();
void Pqi_set_i_scale(float32_t val);
void Pqi_fftCalculos();

#endif /* PQI_H_ */
