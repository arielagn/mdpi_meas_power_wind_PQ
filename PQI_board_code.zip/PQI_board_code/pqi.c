/*
 * pqi.cpp
 *
 *  Created on: May 18, 2023
 *      Author: ariel
 */

#include "pqi.h"
#include "gpio.h"

static uint16_t AD_Res_v[2048];
static uint16_t AD_Res_i[2048];
static float32_t v_sample[1024];
static float32_t i_sample[1024];
static float32_t complexFFT[1024];
static float32_t powerFFT[1024];
float32_t resultados[800];
static float32_t v_rms;
static float32_t v_dc;
static float32_t i_rms;
static float32_t i_dc;
static uint16_t counter;
static uint16_t pqi_counter;

static uint16_t v_index;
static uint16_t i_index;
static float32_t v_dc_offset;
static float32_t v_scale;
static float32_t i_dc_offset;
static float32_t i_scale;
static float32_t v_real_1er;
static float32_t v_imag_1er;
static float32_t i_real_1er;
static float32_t i_imag_1er;

//static uint8_t buffCmplFlag;
static uint8_t pqi_sts;
arm_rfft_fast_instance_f32 s;
arm_status status;

// getter y setter de contador
uint16_t Pqi_getCounter() {
	return(pqi_counter);
}
void Pqi_setCounter(uint16_t count){
	pqi_counter=count;
}
// getter y setter de calibracion
float32_t Pqi_get_v_dc_offset() {
	return (v_dc_offset);
}
void Pqi_set_v_dc_offset(float32_t val) {
	v_dc_offset=val;
}
float32_t Pqi_get_v_scale() {
	return (v_scale);
}
void Pqi_set_v_scale(float32_t val) {
	v_scale=val;
}
float32_t Pqi_get_i_dc_offset() {
	return (i_dc_offset);
}
void Pqi_set_i_dc_offset(float32_t val) {
	i_dc_offset=val;
}
float32_t Pqi_get_i_scale() {
	return (i_scale);
}
void Pqi_set_i_scale(float32_t val) {
	i_scale=val;
}
// getter y setter de pqi_task
uint8_t Pqi_getSts() {
	return (pqi_sts);
}
void Pqi_setSts(uint8_t sts) {
	pqi_sts=sts;
}
// Resetea index de buffer de conversion
void Pqi_resetIndex(){
	v_index=0;
	i_index=0;
}
// Funcion que se llama desde el callback de convwersion finalizada de ADC
// @Param:
//     uint16_t val: valor convertido
//     uint8_t adc: adc que convirtio 2 para ADC2 y 3 para ADC3
void Adc_ConvHandler(uint16_t val,uint16_t adc){
	/*
	if (adc==2) {
		AD_Res_i[i_index]=val;
		i_index++;
		if (i_index==2048) {
			i_index=0;
		}
	}
	if (adc==3) {
		AD_Res_v[v_index]=val;
		v_index++;
		if (v_index==2048) {
			v_index=0;
			Pqi_task(1);
			HAL_GPIO_TogglePin(test_GPIO_Port, test_Pin);
			//buffCmplFlag=2;
		}
		if (v_index==1024) {
			Pqi_task(0);
			HAL_GPIO_TogglePin(test_GPIO_Port, test_Pin);
			//buffCmplFlag=1;
		}
	}
*/
	AD_Res_v[v_index]=val;
	AD_Res_i[v_index]=adc;
	v_index++;
	if (v_index==2048) {
		v_index=0;
		Pqi_task(1);
		HAL_GPIO_TogglePin(test_GPIO_Port, test_Pin);
		//buffCmplFlag=2;
	}
	if (v_index==1024) {
		Pqi_task(0);
		HAL_GPIO_TogglePin(test_GPIO_Port, test_Pin);
		//buffCmplFlag=1;
	}
}

#define idle 0
#define iniciar_medicion 1
#define midiendo 2
#define medicion_terminada 3
#define iniciar_muestra_t 4
#define muestra_t 5
#define muestra_t_terminada 6
#define iniciar_cal 7
#define calibracion 8
#define cal_terminada 9
// Tarea pqi
void Pqi_task(uint8_t bank) {
	//Escalado de las muestras de corriente y de tension. Separo bancos
	for(int i=0;i<1024;i++) {
		v_sample[i]=(((AD_Res_v[bank*1024+i])*3.3/65536)-v_dc_offset)*v_scale;
		i_sample[i]=(((AD_Res_i[bank*1024+i])*3.3/65536)-i_dc_offset)*i_scale;
	}
	switch (pqi_sts) {
	case idle:
		for(int i=0;i<800;i++){
			resultados[i]=0;
		}
		break;
	case iniciar_medicion:
		counter=0;
		pqi_sts++;
		break;
	case midiendo:
		Pqi_fftCalculos();
		if (counter>=pqi_counter-1) {
			pqi_sts++;
			for(int i=0;i<159;i++) {
				resultados[i]=resultados[i]/pqi_counter;
			}
		}
		counter++;
		break;
	case medicion_terminada:
		break;
	case iniciar_muestra_t:
		counter=0;
		pqi_sts++;
		break;
	case muestra_t:
		arm_rms_f32(v_sample,1024,&v_rms); // v RMS
		arm_mean_f32(v_sample,1024,&v_dc); // v DC
		arm_rms_f32(i_sample,1024,&i_rms); // i RMS
		arm_mean_f32(i_sample,1024,&i_dc); // i DC
		resultados[0]=resultados[0]+v_rms;
		resultados[1]=resultados[1]+v_dc;
		resultados[2]=resultados[2]+i_rms;
		resultados[3]=resultados[3]+i_dc;
		if (counter>=pqi_counter-1) {
			pqi_sts++;
			resultados[0]=resultados[0]/pqi_counter;
			resultados[1]=resultados[1]/pqi_counter;
			resultados[2]=resultados[2]/pqi_counter;
			resultados[3]=resultados[3]/pqi_counter;
			for (int i=0;i<397;i++) {
				resultados[i+4]=v_sample[i];
				resultados[i+402]=i_sample[i];
			}
		}
		counter++;
		break;
	case muestra_t_terminada:
		break;
	case iniciar_cal:   // Tarea para obtener promedios de DC y niveles para poder ajustar
		counter=0;
		pqi_sts++;
		break;
	case calibracion:
		arm_rms_f32(v_sample,1024,&v_rms); // v RMS
		arm_mean_f32(v_sample,1024,&v_dc); // v DC
		arm_rms_f32(i_sample,1024,&i_rms); // i RMS
		arm_mean_f32(i_sample,1024,&i_dc); // i DC
		resultados[0]=resultados[0]+v_rms;
		resultados[1]=resultados[1]+v_dc;
		resultados[2]=resultados[2]+i_rms;
		resultados[3]=resultados[3]+i_dc;
		if (counter>=pqi_counter-1) {
			pqi_sts++;
			resultados[0]=resultados[0]/pqi_counter;
			resultados[1]=resultados[1]/pqi_counter;
			resultados[2]=resultados[2]/pqi_counter;
			resultados[3]=resultados[3]/pqi_counter;
		}
		counter++;
		break;
	case cal_terminada:
		break;
	default:
		break;
	}
}

// Calculos empleando la FFT
void Pqi_fftCalculos() {

	// calculos en funcion del tiempo
	arm_rms_f32(v_sample,1024,&v_rms); // v RMS
	arm_mean_f32(v_sample,1024,&v_dc); // v DC
	arm_rms_f32(i_sample,1024,&i_rms); // i RMS
	arm_mean_f32(i_sample,1024,&i_dc); // i DC
	resultados[155]=resultados[155]+v_rms;
	resultados[156]=resultados[156]+v_dc;
	resultados[157]=resultados[157]+i_rms;
	resultados[158]=resultados[158]+i_dc;
	// Realizo la FFT para tension
	status= ARM_MATH_SUCCESS;
	status= arm_rfft_fast_init_f32(&s,1024);
	uint32_t ifftFlag=0;
	arm_rfft_fast_f32(&s,v_sample,complexFFT,ifftFlag);
	// Guardo solo lo del armonico 10
	v_real_1er=complexFFT[20]*2/1024/sqrt(2);
	v_imag_1er=complexFFT[21]*2/1024/sqrt(2);
	// saco el espectro magnitud
	arm_cmplx_mag_f32(complexFFT,powerFFT,512);
	/*
	for (int i=0;i<512;i++) {
		realFFT[i]=complexFFT[i*2]*2/1024/sqrt(2);
		imagFFT[i]=complexFFT[(i*2)+1]*2/1024/sqrt(2);
		powerFFT[i]=sqrt(realFFT[i]*realFFT[i]+imagFFT[i]*imagFFT[i]);
	}
	*/
	// Agrupo armonicos de tension segun IEC61000-4-7 5.6
	// Resultados del 200 al 249 corresponden al armonico 1 a 50
	for (int i=1;i<51;i++) {
		resultados[i+199]=sqrt(pow(powerFFT[i*10-1]*2/1024/sqrt(2),2)+
				pow(powerFFT[i*10]*2/1024/sqrt(2),2)+pow(powerFFT[i*10+1]*2/1024/sqrt(2),2));
	}
	// Realizo la FFT para corriente
	ifftFlag=0;
	arm_rfft_fast_f32(&s,i_sample,complexFFT,ifftFlag);
	// Guardo solo lo del armonico 10
	i_real_1er=complexFFT[20]*2/1024/sqrt(2);
	i_imag_1er=complexFFT[21]*2/1024/sqrt(2);
	arm_cmplx_mag_f32(complexFFT,powerFFT,512);
	// Agrupo armonicos de corriente segun IEC61000-4-7 5.5.1
	// Resultados del 250 al 299 corresponden al armonico 1 a 50
		for (int i=1;i<51;i++) {
			// calculo de armonicos
			resultados[i+249]=sqrt(pow(powerFFT[i*10-5]*2/1024/sqrt(2),2)/2+
					pow(powerFFT[i*10-4]*2/1024/sqrt(2),2)+pow(powerFFT[i*10-3]*2/1024/sqrt(2),2)+
					pow(powerFFT[i*10-2]*2/1024/sqrt(2),2)+pow(powerFFT[i*10-1]*2/1024/sqrt(2),2)+
					pow(powerFFT[i*10]*2/1024/sqrt(2),2)+pow(powerFFT[i*10+1]*2/1024/sqrt(2),2)+
					pow(powerFFT[i*10+2]*2/1024/sqrt(2),2)+pow(powerFFT[i*10+3]*2/1024/sqrt(2),2)+
					pow(powerFFT[i*10+4]*2/1024/sqrt(2),2)+pow(powerFFT[i*10+5]*2/1024/sqrt(2),2)/2);
			// calculo de interarmonicos
			resultados[i+299]=sqrt(pow(powerFFT[i*10+2]*2/1024/sqrt(2),2)+
					pow(powerFFT[i*10+3]*2/1024/sqrt(2),2)+pow(powerFFT[i*10+4]*2/1024/sqrt(2),2)+
					pow(powerFFT[i*10+5]*2/1024/sqrt(2),2)+pow(powerFFT[i*10+6]*2/1024/sqrt(2),2)+
					pow(powerFFT[i*10+7]*2/1024/sqrt(2),2)+pow(powerFFT[i*10+8]*2/1024/sqrt(2),2));
		}
	// DC corriente
	resultados[150]=resultados[150]+(powerFFT[0]*2/1024/sqrt(2));
	// Potencia aparente
	resultados[151]=resultados[151]+(sqrt(pow(v_real_1er,2)+pow(v_imag_1er,2))*sqrt(pow(i_real_1er,2)+pow(i_imag_1er,2)));
	// Potencia activa
	resultados[152]=resultados[152]+(v_real_1er*i_real_1er+v_imag_1er*i_imag_1er);
	// Potencia reactiva
	resultados[153]=resultados[153]+(v_imag_1er*i_real_1er-v_real_1er*i_imag_1er);
	// THC
	float32_t suma_armo=0;
	for (int i=1;i<51;i++){
		suma_armo=suma_armo+pow(resultados[i+250],2);
	}
	resultados[154]=resultados[154]+sqrt(suma_armo)/resultados[250]*100;
	// Acumulo los valores de armonicos para promedio
	for (int i=0;i<150;i++) {
		resultados[i]=resultados[i]+resultados[200+i];
	}
}
